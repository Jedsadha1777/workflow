<?php

namespace App\Filament\App\Resources;

use App\Filament\App\Resources\TemplateDocumentResource\Pages;
use App\Models\TemplateDocument;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Support\HtmlString;
use Illuminate\Database\Eloquent\Model;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;

class TemplateDocumentResource extends Resource
{
    protected static ?string $model = TemplateDocument::class;
    protected static ?string $navigationIcon = 'heroicon-o-document-text';
    protected static ?string $navigationLabel = 'Template Documents';
    protected static ?string $navigationGroup = 'Management';

    public static function canViewAny(): bool { return true; }
    public static function canEdit(Model $record): bool { return true; }
    public static function canCreate(): bool { return true; }
    public static function canDeleteAny(): bool { return true; }

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make()->schema([
                Forms\Components\TextInput::make('name')->required()->maxLength(255),
                Forms\Components\Toggle::make('is_active')->default(true),
            ])->columns(2),

            Forms\Components\Section::make('Content')->schema([
                Forms\Components\FileUpload::make('excel_file')
                    ->label('Upload Excel File')
                    ->acceptedFileTypes(['application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'])
                    ->disk('public')
                    ->directory('templates')
                    ->downloadable(),

                Forms\Components\Placeholder::make('luckysheet_editor')
                    ->label('Spreadsheet Viewer')
                    ->content(function ($record) {
                        if (!$record || !$record->excel_file) {
                            return new HtmlString('<p class="text-gray-500">Save the form with an Excel file first</p>');
                        }
                        
                        $path = storage_path('app/public/' . $record->excel_file);
                        if (!file_exists($path)) {
                            return new HtmlString('<p class="text-red-500">File not found</p>');
                        }
                        
                        try {
                            $spreadsheet = IOFactory::load($path);
                            $worksheet = $spreadsheet->getActiveSheet();
                            
                            $data = [];
                            $maxRow = min(50, $worksheet->getHighestRow());
                            $maxCol = min(20, Coordinate::columnIndexFromString($worksheet->getHighestColumn()));
                            
                            for ($r = 1; $r <= $maxRow; $r++) {
                                $row = [];
                                for ($c = 1; $c <= $maxCol; $c++) {
                                    $colLetter = Coordinate::stringFromColumnIndex($c);
                                    $cell = $worksheet->getCell($colLetter . $r);
                                    $row[] = ['v' => $cell->getValue(), 'm' => $cell->getFormattedValue()];
                                }
                                $data[] = $row;
                            }
                            
                            $sheets = [['name' => $worksheet->getTitle(), 'data' => $data]];
                            $json = json_encode($sheets);
                            $id = 'luckysheet_' . uniqid();
                            
                            $html = '';
                            $html .= '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/luckysheet@latest/dist/css/luckysheet.css"/>';
                            $html .= '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/luckysheet@latest/dist/plugins/css/pluginsCss.css"/>';
                            $html .= '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/luckysheet@latest/dist/plugins/plugins.css"/>';
                            $html .= '<div id="' . $id . '" style="margin:10px 0;width:100%;height:600px;border:1px solid #ddd"></div>';
                            $html .= '<script src="https://cdn.jsdelivr.net/npm/luckysheet@latest/dist/plugins/js/plugin.js"></script>';
                            $html .= '<script src="https://cdn.jsdelivr.net/npm/luckysheet@latest/dist/luckysheet.umd.js"></script>';
                            $html .= '<script>';
                            $html .= '(function(){';
                            $html .= 'var containerId = "' . $id . '";';
                            $html .= 'var sheetData = ' . $json . ';';
                            $html .= 'var attempts = 0;';
                            $html .= 'function init(){';
                            $html .= 'if(window.luckysheet){';
                            $html .= 'luckysheet.create({container:containerId,data:sheetData,showinfobar:false,showsheetbar:true});';
                            $html .= '}else if(attempts<10){';
                            $html .= 'attempts++;';
                            $html .= 'setTimeout(init,500);';
                            $html .= '}';
                            $html .= '}';
                            $html .= 'setTimeout(init,500);';
                            $html .= '})();';
                            $html .= '</script>';
                            
                            return new HtmlString($html);
                            
                        } catch (\Exception $e) {
                            return new HtmlString('<p class="text-red-500">Error: ' . htmlspecialchars($e->getMessage()) . '</p>');
                        }
                    }),

                Forms\Components\Hidden::make('content')->default(''),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')->searchable()->sortable(),
                Tables\Columns\IconColumn::make('is_active')->boolean(),
                Tables\Columns\TextColumn::make('created_at')->dateTime()->sortable(),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListTemplateDocuments::route('/'),
            'create' => Pages\CreateTemplateDocument::route('/create'),
            'edit' => Pages\EditTemplateDocument::route('/{record}/edit'),
        ];
    }
}