<?php

namespace Database\Seeders;

use App\Enums\UserRole;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        User::create([
            'name' => 'Admin',
            'email' => 'admin@example.com',
            'password' => bcrypt('password'),
            'role' => UserRole::ADMIN,
            'department' => 'Administration',
        ]);

        $userRoles = [
            ['name' => 'LD User', 'email' => 'ld@example.com', 'role' => UserRole::LD, 'department' => 'Logistics'],
            ['name' => 'DM User', 'email' => 'dm@example.com', 'role' => UserRole::DM, 'department' => 'Development'],
            ['name' => 'DCC User', 'email' => 'dcc@example.com', 'role' => UserRole::DCC, 'department' => 'Control'],
            ['name' => 'MD User', 'email' => 'md@example.com', 'role' => UserRole::MD, 'department' => 'Management'],
            ['name' => 'ACC User', 'email' => 'acc@example.com', 'role' => UserRole::ACC, 'department' => 'Accounting'],
            ['name' => 'IT User', 'email' => 'it@example.com', 'role' => UserRole::IT, 'department' => 'IT'],
        ];

        foreach ($userRoles as $userData) {
            User::create([
                'name' => $userData['name'],
                'email' => $userData['email'],
                'password' => bcrypt('password'),
                'role' => $userData['role'],
                'department' => $userData['department'],
            ]);
        }
    }
}
