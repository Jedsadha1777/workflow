<?php

namespace App\Filament\App\Resources\DocumentResource\Pages;

use App\Filament\App\Resources\DocumentResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDocument extends CreateRecord
{
    protected static string $resource = DocumentResource::class;

    protected function mutateFormDataBeforeCreate(array $data): array
    {
        $data['creator_id'] = auth()->id();
        $data['department'] = auth()->user()->department;
        
        return $data;
    }

    protected function afterCreate(): void
    {
        $approvers = $this->data['approvers'] ?? [];
        
        foreach ($approvers as $index => $approver) {
            $this->record->approvers()->create([
                'approver_id' => $approver['approver_id'],
                'step_order' => $index + 1,
            ]);
        }
    }
}
