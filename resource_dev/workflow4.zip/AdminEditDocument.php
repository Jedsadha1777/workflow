<?php

namespace App\Filament\Admin\Resources\DocumentResource\Pages;

use App\Filament\Admin\Resources\DocumentResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditDocument extends EditRecord
{
    protected static string $resource = DocumentResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }

    protected function mutateFormDataBeforeFill(array $data): array
    {
        $data['approvers'] = $this->record->approvers()
            ->orderBy('step_order')
            ->get()
            ->toArray();

        return $data;
    }

    protected function afterSave(): void
    {
        if (isset($this->data['approvers'])) {
            $this->record->approvers()->delete();
            
            foreach ($this->data['approvers'] as $index => $approver) {
                $this->record->approvers()->create([
                    'approver_id' => $approver['approver_id'],
                    'step_order' => $index + 1,
                ]);
            }
        }
    }
}
