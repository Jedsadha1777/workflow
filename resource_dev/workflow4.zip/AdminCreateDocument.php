<?php

namespace App\Filament\Admin\Resources\DocumentResource\Pages;

use App\Filament\Admin\Resources\DocumentResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDocument extends CreateRecord
{
    protected static string $resource = DocumentResource::class;

    protected function afterCreate(): void
    {
        $approvers = $this->data['approvers'] ?? [];
        
        foreach ($approvers as $index => $approver) {
            $this->record->approvers()->create([
                'approver_id' => $approver['approver_id'],
                'step_order' => $index + 1,
            ]);
        }
    }
}
